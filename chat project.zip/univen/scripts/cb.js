//container opening and closing
var coll = document.getElementsByClassName("collapsible");

for (let i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function () {// container appears once we click
        this.classList.toggle("active");

        var content = this.nextElementSibling;

        if (content.style.maxHeight) {
            content.style.maxHeight = null;
        } else {
            content.style.maxHeight = content.scrollHeight + "px";
        }
       
    });
/*    const button = document.querySelector('.collapsible');
button.addEventListener('click', () => {
  button.style.display = 'none';
});


}
const exitButton = document.querySelector('.exit-button');
const chatBlock = document.querySelector('.full-chat-block');

exitButton.addEventListener('click', () => {
    chatBlock.style.display = 'none';
});
*/
const registerBtn = document.querySelector('.register-btn');

registerBtn.addEventListener('click', () => {
  const steps = "<span style='color: red;'>'Step 1:</span> Get started by clicking on the option button. It's like opening the door to a world of endless possibilities!<br><span style='color: red;'>Step 2:</span> Next, select the 'Academic Registration' option. This step is like choosing the perfect outfit for your first day of school.<br><span style='color: red;'> Step 3:</span> Make sure to carefully read and accept the rules and regulations. Think of it like signing a contract with your future self, committing to achieving your goals. <br><span style='color: red;'>Step 4:</span> Finally, hit the 'Submit Registration' button! This is like hitting the jackpot and starting your academic journey with a bang!With these steps, you're on your way to achieving great things! Let's go!";
  // Replace this with the code that displays the steps to the user
});

/*

const exitButton = document.querySelector('.exit-button');
const chatBlock = document.querySelector('.full-chat-block');

exitButton.addEventListener('click', () => {
  chatBlock.style.display = 'none';
  button.style.display = 'collapsible';
});*/
const chatButton = document.getElementById("chat-button");
const exitButton = document.querySelector('.exit-button');
const chatBlock = document.querySelector('.full-chat-block');

chatButton.addEventListener('click', () => {
  chatBlock.style.display = 'block';
  chatButton.style.display = 'none';
  
});

exitButton.addEventListener('click', () => {
  chatBlock.style.display = 'none';
  chatButton.style.display = 'block'; // Make the chat button visible again
});


}
//show texting time
function getTime() {
    let today = new Date();
    hours = today.getHours();
    minutes = today.getMinutes();

    if (hours < 10) {
        hours = "0" + hours;
    }

    if (minutes < 10) {
        minutes = "0" + minutes;
    }

    let time ='<span style="color: white;">' +hours + ":" + minutes+'</span>';
    return time;
}
// Display a message to the user on page load
window.onload = function() {
    //alert("Welcome to the UNIVEN website! Need help with registration? Chat with our friendly assistant by clicking on the chatbot button located at the bottom right corner of the page. We're here to help you every step of the way");
    const welcomeMessage = new SpeechSynthesisUtterance('Welcome to the UNIVEN website, if you want any help through registration, click on the chatbot button located at the bottom right  of the page.');
    window.speechSynthesis.speak(welcomeMessage);
    alert("Need help with registration? Chat with our friendly assistant by clicking on the chatbot button located at the bottom right  of the page. We're here to help you every step of the way.");
};

  
//first message
function firstBotMessage() {
  let firstMessage = 'Welcome! I\'m Omega, your personal assistant for Univen registration.I am available for 24/7 for any help through registration.';

let secondMessage = ' To get started, simply choose from the list below and enter the corresponding number for the help you need Let\'s get started!'

document.getElementById("botStarterMessage").innerHTML = '<p class="botText"><span>' + firstMessage + '</span></p>' + '<p class="botText"><span>' + secondMessage + '</span></p>';

const buttonContainer = document.getElementById("button-container");
}
 
    /*let firstMessage = 'Welcome! Im Omega, your personal assistant for Univen registration. Let me guide you through the process. To get started, simply choose from the list below and enter the corresponding number for the help you need'


    document.getElementById("botStarterMessage").innerHTML = '<p class="botText"><span>' + firstMessage + '</span></p>';

    const buttonContainer = document.getElementById("button-container");

   
  }*/


let time = getTime();//retriving time

$("#chat-timestamp").append(time);
document.getElementById("userInput").scrollIntoView(false);


firstBotMessage();

// Retrieves the response
function getHardResponse(userText) {
    let botResponse = getBotResponse(userText);
    let botHtml = '<img src="https://th.bing.com/th/id/OIP.I9KrlBSL9cZmpQU3T2nq-AHaIZ?pid=ImgDet&rs=1" style="width: 50px;border-radius: 50%; height: 50px; margin-right: 10px;left:50%; vertical-align: middle;" class="bot-img"/><p class="botText"><span>' + botResponse + '</span></p>';
    
    $("#chatbox").append(botHtml);
    let newMessage = document.getElementById("chatbox").lastElementChild;
    newMessage.scrollIntoView({behavior: "smooth", block: "end", inline: "nearest"});
  
    $("#chatbox").scrollTop($("#chatbox")[10].scrollHeight);
    document.getElementById("chat-bar-bottom").scrollIntoView(true);
     
     }




//Gets the text text from the input box and processes it
function getResponse() {
    let userText = $("#textInput").val();

    if (userText == "") {
        userText = "Omega HERE";
    }

    let userHtml = '<p class="userText"><span>' + userText + '</span></p>';

    $("#textInput").val("");
    $("#chatbox").append(userHtml);
    document.getElementById("chat-bar-bottom").scrollIntoView(true);

    setTimeout(() => {
        getHardResponse(userText);
    }, 1000)

}

// Handles sending text via button clicks
function buttonSendText(sampleText) {
    let userHtml = '<p class="userText"><span>' + sampleText + '</span></p>';

    $("#textInput").val("");
    $("#chatbox").append(userHtml);
    document.getElementById("chat-bar-bottom").scrollIntoView(true);

 //respond time after user enter message
 setTimeout(() => {
    getHardResponse(sampleText);
}, 1000)
}

function sendButton() {
    var userInput = document.getElementById("textInput").value.trim();
  if (userInput !== "") {
getResponse();
}
}
function showHelp() {
  window.location.href = "register.html";
  }
  
function commentButton() {
    var commentBox = document.getElementById("comment-box");
    if (commentBox.style.display === "none") {
      commentBox.style.display = "block";
    } else {
      commentBox.style.display = "none";
    }
    commentBox.style.position = "fixed";
    commentBox.style.top = "80%";
    commentBox.style.left = "40%";
    commentBox.transform = "translate(-50%, -50%)";
    commentBox.style.width = "50%";
    commentBox.style.height = "100px";
    
  }
  
  function submitComment() {
    var commentBox = document.getElementById("comment-box");
    var commentText = commentBox.getElementsByTagName("textarea")[0].value;
    console.log(commentText);
    commentBox.style.display = "none";
  }
  
  

// Press enter to send a message
$("#textInput").keypress(function (e) {
if (e.which == 13) {//key code for enter
    if ($(this).val().trim() !== '') {
   getResponse();}
}
function showOptions() {
   var options = document.getElementById("options");
   if (options.style.display === "none") {
     options.style.display = "block";
   } else {
     options.style.display = "none";
   }
 }
 const exitButton = document.querySelector('.top-right-button');
const chatBlock = document.querySelector('full-chat-block');

exitButton.addEventListener('click', function() {
    chatBlock.style.display = 'none';
});


});