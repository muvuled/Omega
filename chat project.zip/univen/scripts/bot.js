
function getBotResponse(input ) {
    input = input.toLowerCase();
  if (input == "hello" || input == "hi" || input == "eta" || input == "hey"|| input == "xor") {
      return "Hi! it's good to see you how can i help you?<br>1.Register<br>2.Add subject to a registration<br>3.print proof of registration<br>4.Access Proof of cost";
     // } else if (input == "menu") {
    //return "Choose an option Below and select a corresponding number<br>1.Register<br>2.Add subject to a registration<br>3.print proof of registration<br>4.Univen website";
  } else if (input == "menu") {
      const button = '<button onclick="showHelp()">Need Help?</button>';
      return '<span class="botText">Choose an option below and select a corresponding number:</span><br>' +
      '<span class="botText">1. Register<br>2. Add subject to a registration<br>3. Print proof of registration<br>4. Univen website</span>' +
      '<br><br>'
      button;
      //} else if (input == "1"|| input == "01"|| input == "1.") {
      //return "  <span style='color: red;'>'Step 1:</span> Get started by clicking on the <span style='color:blue;'>option button</span>.You will see some of the options you can be hovering on!<br><span style='color: red;'>Step 2:</span> Next, select the <span style='color:blue;'>Academic Registration' option</span><br><span style='color: red;'> Step 3:</span> Make sure to carefully <span style='color:blue;'>read and accept the rules and regulations</span><br><span style='color: red;'>Step 4:</span> Finally, hit the <span style='color:blue;'>'Submit Registration</span> button!<br></span>' +'<br><br>' +'<span class=botText>To access a menu of options, please type 'menu' and the available choices will be presented for your selection.</span>";
  } else if (input == "1"|| input == "01"|| input == "1.") {
      const button = '<button onclick="showHelp()">Need Help?</button>';
      return " <span style='color: red;'>'Step 1:</span> Get started by clicking on the <span style='color:blue;'>option button</span>.You will see some of the options you can be hovering on!<br><span style='color: red;'>Step 2:</span> Next, select the <span style='color:blue;'>Academic Registration' option</span><br><span style='color: red;'> Step 3:</span> Make sure to carefully <span style='color:blue;'>read and accept the rules and regulations</span><br><span style='color: red;'>Step 4:</span> Finally, hit the suubmit button<br></span>" + "<br><br>" + "<span class='botText'>To access a menu of options, please type 'menu' and the available choices will be presented for your selection.If you want moe information on registration  click the need help button"+ button +"</span>";
      
  } else if (input == "2"|| input == "02"|| input == "2.") {
      return "<span style='color: red;'>STEP 1:</span> Ready, Set, Press! Find the <span style='color:blue;'>Option button </span>on your screen and give it a satisfying click.<br><span style='color: red;'>STEP 2:</span> Academic Registration You're now in the registration portal! Look for the <span style='color:blue;'>Academic Registration button</span> and give it a tap.<br><span style='color: red;'> STEP 3:</span> Rule with Acceptance process, you'll need to accept the rules and regulations. Give them a quick read and hit that Accept button to proceed.<br><span style='color: red;'> STEP 4:</span> Add Subjects with Ease  Almost there! It's time to select your desired subjects by pressing the Add Subject button. This will take you to a list of courses to choose from, so pick wisely!<br></span>' +'<br><br>' +'<span class=botText>To access a menu of options, please type 'menu' and the available choices will be presented for your selection.</span>";
    } else if (input == "3"|| input == "03"|| input == "3.") {
      
  
      return "<span style='color: red;'>STEP1.</span>Click on the <span style='color: blue;'>Options button</span> to begin <br><span style='color: red;'>STEP2.</span>Select <span style='color: blue;'>Academic Registration</span>.<br><span style='color: red;'>STEP3.</span>Click on <span style='color:blue;'>Proof of Registration</span>.`  </span>' +'<br><br>' +'<span class=botText>To access a menu of options, please type 'menu' and the available choices will be presented for your selection.</span>";
  
      
      
  } else if (input == "4"|| input == "04"|| input == "4.") {
      window.location.href = "https://www.univen.ac.za/academic-calendar/";
  } else if (input == "registration") {
      return "Type Menu ";
  } else if (input == "bye") {
      return "Talk to you later!";
  } else {
      return "I'm not able to help you with that! <br>simply choose from the list below<br> and enter the corresponding number<br> for the help you need.<br>1.Register<br>2.Add subject to a registration<br>3.print proof of registration<br>4.Access Proof of cost";
      
  }
  }
  